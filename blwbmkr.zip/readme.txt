=== blwbmkr ===
Contributors: Bali Web Maker
Requires at least: 6.0
Tested up to: 6.3
Requires PHP: 5.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

bali web maker tour

== Changelog ==

= 1.0.0 =
* Initial release

== Copyright ==

blwbmkr WordPress Theme, (C) 2023 Bali Web Maker
blwbmkr is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
