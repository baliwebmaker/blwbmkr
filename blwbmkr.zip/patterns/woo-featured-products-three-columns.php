<?php
/**
 * Title: Featured products columns block
 * Slug: blwbmkr/featured-producst-columns
 * Categories: blwbmkr-woo
 * Block Types: core/columns
 *
 * @package blwbmkr
 * @since 1.0.4
 */

?>
<!-- wp:group {"align":"wide","style":{"spacing":{"blockGap":"0px"}}} -->
<div class="wp-block-group alignwide"><!-- wp:woocommerce/featured-product {"contentAlign":"left","dimRatio":0,"editMode":false,"align":"wide","backgroundColor":"white","textColor":"secondary"} /-->
<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":"0px"}}} --><div class="wp-block-columns alignwide"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:woocommerce/featured-product {"dimRatio":20,"editMode":false,"backgroundColor":"primary","textColor":"secondary"} /--></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:woocommerce/featured-product {"dimRatio":20,"editMode":false,"backgroundColor":"primary","textColor":"secondary"} /--></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:woocommerce/featured-product {"dimRatio":20,"editMode":false,"backgroundColor":"primary","textColor":"secondary"} /--></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
