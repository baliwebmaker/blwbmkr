<?php
/**
 * Title: Full width featured product
 * Slug: blwbmkr/full-width-featured-product
 * Categories: blwbmkr-woo
 *
 * @package blwbmkr
 * @since 1.0.4
 */

?>
<!-- wp:woocommerce/featured-product {"contentAlign":"left","dimRatio":0,"editMode":false,"align":"full","backgroundColor":"white","textColor":"secondary"} /-->
