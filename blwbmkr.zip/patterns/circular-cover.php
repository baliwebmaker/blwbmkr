<?php
/**
 * Title: Circular cover block pattern
 * Slug: blwbmkr/circular-cover
 * Inserter: no
 * RETIRED
 *
 * @package blwbmkr
 * @since 1.0.4
 */

return array(
	'title'    => esc_html__( 'Circular cover block with heading', 'blwbmkr' ),
	'inserter' => false,
	'content'  => '',
);
